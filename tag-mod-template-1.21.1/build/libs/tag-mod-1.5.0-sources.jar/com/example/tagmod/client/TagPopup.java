package com.example.tagmod.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;

public class TagPopup {

    private static String text = null;
    private static long endTime = 0;
    private static int color = 0xFFFFFF;

    public static void show(String msg, int colorRgb) {
        text = msg;
        color = colorRgb;
        endTime = System.currentTimeMillis() + 1000;
    }

    public static void register() {

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {

            if (text == null) return;
            if (System.currentTimeMillis() > endTime) return;

            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) return;

            class_327 tr = client.field_1772;

            int width = client.method_22683().method_4486();
            int height = client.method_22683().method_4502();

            float x = width / 2f - tr.method_1727(text) / 2f;
            float y = height / 2f;

            drawContext.method_51433(
                    tr,
                    text,
                    (int) x,
                    (int) y,
                    color,
                    true
            );
        });
    }
}