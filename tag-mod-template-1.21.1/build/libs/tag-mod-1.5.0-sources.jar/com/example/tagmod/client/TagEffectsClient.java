package com.example.tagmod.client;

import com.example.tagmod.TagGame;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class TagEffectsClient {

    public static void register() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            class_746 player = class_310
                    .method_1551()
                    .field_1724;

            if (player == null) {
                return;
            }

            boolean running = TagGame.gameRunning;

            if (!running) {
                player.method_5834(false);
            }
        });
    }
}