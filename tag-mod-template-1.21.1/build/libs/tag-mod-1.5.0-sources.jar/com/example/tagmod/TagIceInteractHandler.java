package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5894;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TagIceInteractHandler {

    // tracks when each player was frozen (ms)
    public static final Map<UUID, Long> FREEZE_TIMERS = new HashMap<>();

    private static final long FREEZE_DURATION_MS = 15_000; // 15 seconds

    public static void register() {

        // hitting ice/barrier block = unfreeze nearby frozen player
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {

            if (world.method_8608()) return class_1269.field_5811;

            if (!(player instanceof class_3222 sp))
                return class_1269.field_5811;

            if (!TagGame.gameRunning || !TagGame.freezeMode)
                return class_1269.field_5811;

            if (!world.method_8320(pos).method_27852(class_2246.field_10295)
                    && !world.method_8320(pos).method_27852(class_2246.field_10499))
                return class_1269.field_5811;

            // only unfrozen runners can unfreeze
            if (!TagGame.isRunner(sp.method_5667())) return class_1269.field_5814;
            if (TagGame.isFrozen(sp.method_5667())) return class_1269.field_5814;

            tryRunnerUnfreeze(sp, pos);

            return class_1269.field_5814;
        });

        // tick: check 15s freeze timers + show countdown on frozen player's screen
        ServerTickEvents.END_SERVER_TICK.register(server -> {

            if (!TagGame.gameRunning || !TagGame.freezeMode) return;

            long now = System.currentTimeMillis();

            for (UUID id : TagGame.FROZEN.toArray(new UUID[0])) {

                Long frozenAt = FREEZE_TIMERS.get(id);
                if (frozenAt == null) continue;

                long elapsed = now - frozenAt;
                long remaining = (FREEZE_DURATION_MS - elapsed) / 1000;

                class_3222 p = server.method_3760().method_14602(id);
                if (p == null) continue;

                if (elapsed >= FREEZE_DURATION_MS) {

                    // unfreeze and make them a freezer
                    TagGame.FROZEN.remove(id);
                    TagGame.FREEZERS.add(id);
                    FREEZE_TIMERS.remove(id);

                    removeIceCage(p);

                    String name = p.method_5477().getString();

                    server.method_3760().method_43514(
                            class_2561.method_43470(name + " was frozen for too long, they became a freezer!")
                                    .method_27692(class_124.field_1075),
                            false
                    );

                    sendTitle(p,
                            class_2561.method_43470("YOU ARE NOW A FREEZER").method_27692(class_124.field_1075),
                            class_2561.method_43470("You were frozen too long!").method_27692(class_124.field_1080));

                    TagGame.syncGlowing(server);

                } else {
                    // show countdown only on the frozen player's screen (action bar)
                    p.field_13987.method_14364(new class_5894(
                            class_2561.method_43470("You will become a freezer in: " + (remaining + 1) + "s")
                                    .method_27692(class_124.field_1075)
                    ));
                }
            }
        });
    }

    private static void tryRunnerUnfreeze(class_3222 clicker, class_2338 clickedPos) {

        for (class_3222 target :
                clicker.method_5682().method_3760().method_14571()) {

            if (!TagGame.isFrozen(target.method_5667())) continue;

            class_2338 base = target.method_24515();

            class_2338[] cage = new class_2338[]{
                    base.method_10074(),
                    base.method_10095(),
                    base.method_10072(),
                    base.method_10078(),
                    base.method_10067(),
                    base.method_10095().method_10084(),
                    base.method_10072().method_10084(),
                    base.method_10078().method_10084(),
                    base.method_10067().method_10084(),
                    base.method_10084().method_10084()
            };

            for (class_2338 b : cage) {
                if (b.equals(clickedPos)) {

                    String targetName = target.method_5477().getString();
                    String clickerName = clicker.method_5477().getString();

                    TagGame.unfreeze(target);
                    FREEZE_TIMERS.remove(target.method_5667());
                    removeIceCage(target);

                    sendTitle(clicker,
                            class_2561.method_43470("You Unfreezed " + targetName).method_27692(class_124.field_1060),
                            class_2561.method_43470("").method_27692(class_124.field_1080));

                    sendTitle(target,
                            class_2561.method_43470("You got Unfreezed by " + clickerName).method_27692(class_124.field_1060),
                            class_2561.method_43470("Run away!").method_27692(class_124.field_1080));

                    return;
                }
            }
        }
    }

    public static void removeIceCage(class_3222 p) {

        class_2338 base = p.method_24515();
        var w = p.method_51469();

        class_2338[] positions = {
                base.method_10074(),
                base.method_10095(),
                base.method_10072(),
                base.method_10078(),
                base.method_10067(),
                base.method_10095().method_10084(),
                base.method_10072().method_10084(),
                base.method_10078().method_10084(),
                base.method_10067().method_10084(),
                base.method_10084().method_10084()
        };

        for (class_2338 b : positions) {
            if (w.method_8320(b).method_27852(class_2246.field_10295)
                    || w.method_8320(b).method_27852(class_2246.field_10499)) {
                w.method_8501(b, class_2246.field_10124.method_9564());
            }
        }
    }

    private static void sendTitle(class_3222 player, class_2561 title, class_2561 subtitle) {
        player.field_13987.method_14364(new class_5904(title));
        player.field_13987.method_14364(new class_5903(subtitle));
    }
}