package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

public class TagHitHandler {

    public static void register() {

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {

            if (world.method_8608()) return class_1269.field_5811;

            if (!(player instanceof class_3222 attacker))
                return class_1269.field_5811;

            if (!(entity instanceof class_3222 target))
                return class_1269.field_5811;

            if (!TagGame.gameRunning)
                return class_1269.field_5811;

            // =====================
            // FREEZE MODE
            // =====================

            if (TagGame.freezeMode) {

                if (!TagGame.isFreezer(attacker.method_5667()))
                    return class_1269.field_5811;

                if (TagGame.isFreezer(target.method_5667()))
                    return class_1269.field_5814;

                if (TagGame.isFrozen(target.method_5667()))
                    return class_1269.field_5814;

                TagGame.freeze(target);

                sendTitle(target,
                        class_2561.method_43470("YOU GOT FROZEN").method_27692(class_124.field_1075),
                        class_2561.method_43470("Wait to be unfrozen!").method_27692(class_124.field_1080));

                sendTitle(attacker,
                        class_2561.method_43470("FROZEN!").method_27692(class_124.field_1075),
                        class_2561.method_43470("You froze " + target.method_5477().getString()).method_27692(class_124.field_1080));

                return class_1269.field_5812;
            }

            // =====================
            // KILLER MODE
            // =====================

            if (TagGame.killerMode) {

                if (!TagGame.isKiller(attacker.method_5667()))
                    return class_1269.field_5811;

                if (target.method_7325())
                    return class_1269.field_5814;

                target.method_7336(net.minecraft.class_1934.field_9219);

                sendTitle(target,
                        class_2561.method_43470("YOU DIED").method_27692(class_124.field_1061),
                        class_2561.method_43470("You were killed!").method_27692(class_124.field_1080));

                sendTitle(attacker,
                        class_2561.method_43470("KILL!").method_27692(class_124.field_1061),
                        class_2561.method_43470("You killed " + target.method_5477().getString()).method_27692(class_124.field_1080));

                return class_1269.field_5812;
            }

            // =====================
            // NORMAL TAG MODE
            // =====================

            if (!TagGame.isChaser(attacker.method_5667()))
                return class_1269.field_5811;

            TagGame.transferChase(attacker.method_5682(), target.method_5667());

            sendTitle(target,
                    class_2561.method_43470("YOU ARE THE CHASER").method_27692(class_124.field_1061),
                    class_2561.method_43470("Chase someone!").method_27692(class_124.field_1080));

            sendTitle(attacker,
                    class_2561.method_43470("YOU ARE A RUNNER").method_27692(class_124.field_1060),
                    class_2561.method_43470("Run away!").method_27692(class_124.field_1080));

            return class_1269.field_5812;
        });
    }

    // 0.75 seconds = ~15 ticks stay time
    public static void sendTitle(class_3222 player, class_2561 title, class_2561 subtitle) {
        player.field_13987.method_14364(new class_5905(5, 15, 5));
        player.field_13987.method_14364(new class_5904(title));
        player.field_13987.method_14364(new class_5903(subtitle));
    }
}