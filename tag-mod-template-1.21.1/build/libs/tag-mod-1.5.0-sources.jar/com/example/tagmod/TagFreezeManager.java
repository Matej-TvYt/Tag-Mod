package com.example.tagmod;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class TagFreezeManager {

    public static final Map<UUID, Long> frozenPlayers = new HashMap<>();

    public static void freezePlayer(class_3222 player) {

        UUID id = player.method_5667();

        frozenPlayers.put(id, System.currentTimeMillis());

        class_2338 pos = player.method_24515();

        player.method_51469().method_8501(pos.method_10095(), class_2246.field_10295.method_9564());
        player.method_51469().method_8501(pos.method_10072(), class_2246.field_10295.method_9564());
        player.method_51469().method_8501(pos.method_10078(), class_2246.field_10295.method_9564());
        player.method_51469().method_8501(pos.method_10067(), class_2246.field_10295.method_9564());

        player.method_7353(
                net.minecraft.class_2561.method_43470("You got Freezed, wait to get Unfreezed.")
                        .method_27692(net.minecraft.class_124.field_1075),
                true
        );
    }

    public static void unfreezePlayer(class_3222 player) {

        UUID id = player.method_5667();

        frozenPlayers.remove(id);

        class_2338 pos = player.method_24515();

        player.method_51469().method_22352(pos.method_10095(), false);
        player.method_51469().method_22352(pos.method_10072(), false);
        player.method_51469().method_22352(pos.method_10078(), false);
        player.method_51469().method_22352(pos.method_10067(), false);

        player.method_7353(
                net.minecraft.class_2561.method_43470("You got Unfreezed")
                        .method_27692(net.minecraft.class_124.field_1078),
                true
        );
    }

    public static boolean isFrozen(UUID id) {
        return frozenPlayers.containsKey(id);
    }
}