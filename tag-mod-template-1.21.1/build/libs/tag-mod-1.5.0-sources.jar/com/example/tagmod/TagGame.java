package com.example.tagmod;

import net.minecraft.class_124;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5894;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class TagGame {

    // =========================
    // MODES
    // =========================

    public static boolean freezeMode = false;
    public static boolean killerMode = false;
    public static boolean gameRunning = false;

    // =========================
    // NORMAL MODE
    // =========================

    public static UUID chaser = null;

    // =========================
    // KILLER MODE
    // =========================

    public static UUID killer = null;
    public static UUID lastKiller = null;

    // =========================
    // FREEZE MODE
    // =========================

    public static final Set<UUID> FREEZERS = new HashSet<>();
    public static final Set<UUID> FROZEN = new HashSet<>();
    public static final Map<UUID, Long> FROZEN_SINCE = new HashMap<>();

    // =========================
    // TRACKING
    // =========================

    public static final Map<UUID, Long> RUNNER_START = new HashMap<>();
    public static final Map<UUID, String> PLAYER_NAMES = new HashMap<>();

    public static UUID longestSurvivor = null;
    public static long longestSurvivalTime = 0;

    public static boolean roundEnding = false;
    public static long roundEndStart = 0;

    // restart countdown
    public static boolean restarting = false;
    public static long restartStartMs = 0;
    public static int restartCountdown = 5;

    private static final Random RANDOM = new Random();

    private static final String TEAM_CHASER  = "tag_chaser";
    private static final String TEAM_FREEZER = "tag_freezer";
    private static final String TEAM_KILLER  = "tag_killer";
    private static final String TEAM_RUNNER  = "tag_runner";

    // =========================
    // CHECKS
    // =========================

    public static boolean isFreezeMode() { return freezeMode && !killerMode; }
    public static boolean isKillerMode() { return killerMode && !freezeMode; }
    public static boolean isFreezer(UUID id) { return FREEZERS.contains(id); }
    public static boolean isFrozen(UUID id) { return FROZEN.contains(id); }
    public static boolean isKiller(UUID id) { return killer != null && killer.equals(id); }
    public static boolean isChaser(UUID id) { return chaser != null && chaser.equals(id); }

    public static boolean isRunner(UUID id) {
        if (killerMode) return !isKiller(id);
        if (freezeMode) return !isFreezer(id);
        return !isChaser(id);
    }

    private static int neededPlayers() {
        // killer and freeze need 2+, normal needs 2+
        return 2;
    }

    // =========================
    // START
    // =========================

    public static void start(MinecraftServer server) {

        List<class_3222> players = server.method_3760().method_14571();

        if (gameRunning) return;

        if (players.size() < 2) {
            server.method_3760().method_43514(
                    class_2561.method_43470("Need at least 2 players to start.").method_27692(class_124.field_1061),
                    false
            );
            return;
        }

        reset(server);

        gameRunning = true;

        PLAYER_NAMES.clear();
        RUNNER_START.clear();

        for (class_3222 p : players) {
            PLAYER_NAMES.put(p.method_5667(), p.method_5477().getString());
        }

        class_3222 selected = players.get(RANDOM.nextInt(players.size()));

        // KILLER MODE
        if (killerMode) {

            killer = selected.method_5667();
            lastKiller = killer;

            for (class_3222 p : players) {
                if (!isKiller(p.method_5667())) {
                    RUNNER_START.put(p.method_5667(), System.currentTimeMillis());
                }
            }

            server.method_3760().method_43514(
                    class_2561.method_43470(selected.method_5477().getString() + " is the KILLER!").method_27692(class_124.field_1061),
                    false
            );

            for (class_3222 p : players) {
                if (isKiller(p.method_5667())) {
                    sendTitle(p,
                            class_2561.method_43470("YOU ARE THE KILLER").method_27692(class_124.field_1061),
                            class_2561.method_43470("Kill everyone!").method_27692(class_124.field_1080));
                } else {
                    sendTitle(p,
                            class_2561.method_43470("YOU ARE A RUNNER").method_27692(class_124.field_1060),
                            class_2561.method_43470("Survive!").method_27692(class_124.field_1080));
                }
            }

            syncGlowing(server);
            return;
        }

        // FREEZE MODE
        if (freezeMode) {

            FREEZERS.add(selected.method_5667());

            for (class_3222 p : players) {
                if (!p.method_5667().equals(selected.method_5667())) {
                    RUNNER_START.put(p.method_5667(), System.currentTimeMillis());
                }
            }

            server.method_3760().method_43514(
                    class_2561.method_43470(selected.method_5477().getString() + " is the FREEZER!").method_27692(class_124.field_1075),
                    false
            );

            for (class_3222 p : players) {
                if (isFreezer(p.method_5667())) {
                    sendTitle(p,
                            class_2561.method_43470("YOU ARE THE FREEZER").method_27692(class_124.field_1075),
                            class_2561.method_43470("Freeze everyone!").method_27692(class_124.field_1080));
                } else {
                    sendTitle(p,
                            class_2561.method_43470("YOU ARE A RUNNER").method_27692(class_124.field_1060),
                            class_2561.method_43470("Avoid the freezer!").method_27692(class_124.field_1080));
                }
            }

            syncGlowing(server);
            return;
        }

        // NORMAL MODE
        chaser = selected.method_5667();

        for (class_3222 p : players) {
            if (!p.method_5667().equals(chaser)) {
                RUNNER_START.put(p.method_5667(), System.currentTimeMillis());
            }
        }

        server.method_3760().method_43514(
                class_2561.method_43470(selected.method_5477().getString() + " is the CHASER!").method_27692(class_124.field_1061),
                false
        );

        for (class_3222 p : players) {
            if (isChaser(p.method_5667())) {
                sendTitle(p,
                        class_2561.method_43470("YOU ARE THE CHASER").method_27692(class_124.field_1061),
                        class_2561.method_43470("Chase someone!").method_27692(class_124.field_1080));
            } else {
                sendTitle(p,
                        class_2561.method_43470("YOU ARE A RUNNER").method_27692(class_124.field_1060),
                        class_2561.method_43470("Run away!").method_27692(class_124.field_1080));
            }
        }

        syncGlowing(server);
    }

    // =========================
    // NORMAL MODE TAG
    // =========================

    public static void transferChase(MinecraftServer server, UUID newChaser) {
        if (!gameRunning) return;
        if (freezeMode) return;
        if (killerMode) return;
        chaser = newChaser;
        syncGlowing(server);
    }

    // =========================
    // FREEZE
    // =========================

    public static void freeze(class_3222 target) {

        if (!gameRunning || !freezeMode) return;

        UUID id = target.method_5667();
        if (FROZEN.contains(id)) return;

        FROZEN.add(id);
        TagIceInteractHandler.FREEZE_TIMERS.put(id, System.currentTimeMillis());

        buildIceCage(target);
    }

    public static void unfreeze(class_3222 target) {

        UUID id = target.method_5667();
        if (!FROZEN.contains(id)) return;

        FROZEN.remove(id);
        TagIceInteractHandler.FREEZE_TIMERS.remove(id);
    }

    // =========================
    // ROLE LEFT — triggers restart countdown (fix 1)
    // =========================

    public static void roleLeft(MinecraftServer server, String playerName, UUID id) {

        if (!gameRunning) return;

        boolean keyPlayerLeft = false;

        if (killerMode && isKiller(id)) keyPlayerLeft = true;
        if (freezeMode && isFreezer(id)) keyPlayerLeft = true;
        if (!killerMode && !freezeMode && isChaser(id)) keyPlayerLeft = true;

        if (!keyPlayerLeft) return;

        int currentPlayers = server.method_3760().method_14571().size();

        // check if enough players remain to restart
        if (currentPlayers < 2) {
            // not enough — end round, tell everyone
            for (class_3222 p : server.method_3760().method_14571()) {
                sendTitle(p,
                        class_2561.method_43470("Round Failed!").method_27692(class_124.field_1061),
                        class_2561.method_43470("Failed to restart: need at least 2 people!").method_27692(class_124.field_1080));
            }

            server.method_3760().method_43514(
                    class_2561.method_43470(playerName + " left the game. Not enough players to restart.").method_27692(class_124.field_1061),
                    false
            );

            stop(server);
            return;
        }

        // enough players — start restart countdown
        server.method_3760().method_43514(
                class_2561.method_43470(playerName + " left the game. Round restarting...").method_27692(class_124.field_1054),
                false
        );

        // stop current round state but keep gameRunning false while counting down
        softReset(server);

        restarting = true;
        restartStartMs = System.currentTimeMillis();
        restartCountdown = 5;

        // show countdown on all screens
        for (class_3222 p : server.method_3760().method_14571()) {
            sendTitle(p,
                    class_2561.method_43470("Round Restarting").method_27692(class_124.field_1054),
                    class_2561.method_43470("Starting in 5...").method_27692(class_124.field_1080));
        }
    }

    // =========================
    // TICK
    // =========================

    public static void tick(MinecraftServer server) {

        // handle restart countdown (fix 1)
        if (restarting) {

            long elapsed = System.currentTimeMillis() - restartStartMs;
            int secondsLeft = 5 - (int)(elapsed / 1000);

            if (secondsLeft != restartCountdown) {
                restartCountdown = secondsLeft;

                if (restartCountdown > 0) {
                    for (class_3222 p : server.method_3760().method_14571()) {
                        p.field_13987.method_14364(new class_5894(
                                class_2561.method_43470("Restarting in " + restartCountdown + "s...").method_27692(class_124.field_1054)
                        ));
                    }
                }
            }

            if (elapsed >= 5000) {
                restarting = false;

                int currentPlayers = server.method_3760().method_14571().size();
                if (currentPlayers < 2) {
                    server.method_3760().method_43514(
                            class_2561.method_43470("Not enough players to restart. Round cancelled.").method_27692(class_124.field_1061),
                            false
                    );
                    for (class_3222 p : server.method_3760().method_14571()) {
                        sendTitle(p,
                                class_2561.method_43470("Round Cancelled!").method_27692(class_124.field_1061),
                                class_2561.method_43470("Need at least 2 players!").method_27692(class_124.field_1080));
                    }
                    return;
                }

                start(server);
            }

            return;
        }

        if (!gameRunning) return;

        syncGlowing(server);

        // KILLER MODE WIN CHECK
        if (killerMode) {

            int alive = 0;
            long longestTime = 0;
            String longestName = "Unknown";

            for (class_3222 p : server.method_3760().method_14571()) {
                if (!isKiller(p.method_5667()) && !p.method_7325()) {
                    alive++;
                }
            }

            for (Map.Entry<UUID, Long> entry : RUNNER_START.entrySet()) {
                UUID id = entry.getKey();
                if (isKiller(id)) continue;
                long survived = System.currentTimeMillis() - entry.getValue();
                if (survived > longestTime) {
                    longestTime = survived;
                    longestName = PLAYER_NAMES.getOrDefault(id, "Unknown");
                }
            }

            if (alive == 0) {

                long seconds = longestTime / 1000;
                long minutes = seconds / 60;
                long secs = seconds % 60;
                String timeStr = minutes > 0 ? minutes + "m " + secs + "s" : secs + "s";

                server.method_3760().method_43514(
                        class_2561.method_43470("All players died! " + longestName + " survived the longest: " + timeStr)
                                .method_27692(class_124.field_1065),
                        false
                );

                spawnSpectatorsNearKiller(server);
                stop(server);
                return;
            }
        }

        // FREEZE MODE WIN CHECK
        if (freezeMode) {

            List<class_3222> allPlayers = server.method_3760().method_14571();

            int unfrozenRunners = 0;
            for (class_3222 p : allPlayers) {
                if (!isFreezer(p.method_5667()) && !isFrozen(p.method_5667())) {
                    unfrozenRunners++;
                }
            }

            if (unfrozenRunners == 0 && !FROZEN.isEmpty()) {

                long longestTime = 0;
                String longestName = "Unknown";

                for (Map.Entry<UUID, Long> entry : RUNNER_START.entrySet()) {
                    UUID id = entry.getKey();
                    if (isFreezer(id)) continue;
                    long survived = System.currentTimeMillis() - entry.getValue();
                    if (survived > longestTime) {
                        longestTime = survived;
                        longestName = PLAYER_NAMES.getOrDefault(id, "Unknown");
                    }
                }

                long seconds = longestTime / 1000;
                long minutes = seconds / 60;
                long secs = seconds % 60;
                String timeStr = minutes > 0 ? minutes + "m " + secs + "s" : secs + "s";

                server.method_3760().method_43514(
                        class_2561.method_43470("All players are frozen! " + longestName + " survived the longest: " + timeStr)
                                .method_27692(class_124.field_1075),
                        false
                );

                stop(server);
            }
        }
    }

    // =========================
    // SPECTATOR SPAWN NEAR KILLER
    // =========================

    private static void spawnSpectatorsNearKiller(MinecraftServer server) {

        if (lastKiller == null) return;

        class_3222 killerPlayer = server.method_3760().method_14602(lastKiller);
        if (killerPlayer == null) return;

        class_3218 world = killerPlayer.method_51469();
        class_2338 killerPos = killerPlayer.method_24515();

        for (class_3222 p : server.method_3760().method_14571()) {
            if (p.method_7325() && !p.method_5667().equals(lastKiller)) {
                class_2338 safePos = findSafeNearbyPos(world, killerPos);
                if (safePos != null) {
                    p.method_14251(world,
                            safePos.method_10263() + 0.5,
                            safePos.method_10264(),
                            safePos.method_10260() + 0.5,
                            p.method_36454(),
                            p.method_36455());
                }
            }
        }
    }

    private static class_2338 findSafeNearbyPos(class_3218 world, class_2338 center) {

        for (int attempts = 0; attempts < 100; attempts++) {

            int dist = 2 + RANDOM.nextInt(4);
            double angle = RANDOM.nextDouble() * 2 * Math.PI;
            int dx = (int) Math.round(Math.cos(angle) * dist);
            int dz = (int) Math.round(Math.sin(angle) * dist);

            class_2338 candidate = center.method_10069(dx, 0, dz);

            for (int dy = 3; dy >= -3; dy--) {
                class_2338 feet = new class_2338(candidate.method_10263(), center.method_10264() + dy, candidate.method_10260());
                class_2338 below = feet.method_10074();
                class_2338 head = feet.method_10084();

                class_2680 belowState = world.method_8320(below);
                class_2680 feetState = world.method_8320(feet);
                class_2680 headState = world.method_8320(head);

                if (!belowState.method_26212(world, below)) continue;
                if (belowState.method_27852(class_2246.field_10164)) continue;
                if (belowState.method_27852(class_2246.field_10382)) continue;
                if (belowState.method_27852(class_2246.field_27879)) continue;
                if (belowState.method_27852(class_2246.field_10102)) continue;
                if (belowState.method_27852(class_2246.field_10255)) continue;
                if (belowState.method_27852(class_2246.field_10534)) continue;
                if (!feetState.method_26215()) continue;
                if (!headState.method_26215()) continue;

                return feet;
            }
        }

        return null;
    }

    // =========================
    // GLOWING WITH COLOURS
    // =========================

    public static void syncGlowing(MinecraftServer server) {

        class_269 scoreboard = server.method_3845();

        setupTeam(scoreboard, TEAM_CHASER,  class_124.field_1061);
        setupTeam(scoreboard, TEAM_FREEZER, class_124.field_1075);
        setupTeam(scoreboard, TEAM_KILLER,  class_124.field_1061);
        setupTeam(scoreboard, TEAM_RUNNER,  class_124.field_1060);

        for (String teamName : new String[]{TEAM_CHASER, TEAM_FREEZER, TEAM_KILLER, TEAM_RUNNER}) {
            class_268 t = scoreboard.method_1153(teamName);
            if (t != null) {
                new HashSet<>(t.method_1204()).forEach(scoreboard::method_1195);
            }
        }

        for (class_3222 p : server.method_3760().method_14571()) {

            p.method_5834(false);

            if (!gameRunning) continue;

            String playerName = p.method_5477().getString();

            if (killerMode) {
                if (isKiller(p.method_5667())) {
                    p.method_5834(true);
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_KILLER));
                } else {
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_RUNNER));
                }

            } else if (freezeMode) {
                if (isFreezer(p.method_5667())) {
                    p.method_5834(true);
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_FREEZER));
                } else {
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_RUNNER));
                }

            } else {
                if (isChaser(p.method_5667())) {
                    p.method_5834(true);
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_CHASER));
                } else {
                    scoreboard.method_1172(playerName, scoreboard.method_1153(TEAM_RUNNER));
                }
            }
        }
    }

    private static void setupTeam(class_269 scoreboard, String name, class_124 color) {
        class_268 team = scoreboard.method_1153(name);
        if (team == null) {
            team = scoreboard.method_1171(name);
        }
        team.method_1141(color);
        team.method_1143(false);
    }

    // =========================
    // STOP
    // =========================

    public static void stop(MinecraftServer server) {

        for (UUID id : new HashSet<>(FROZEN)) {
            class_3222 p = server.method_3760().method_14602(id);
            if (p != null) {
                TagIceInteractHandler.removeIceCage(p);
            }
        }

        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_5834(false);
            if (p.method_7325()) {
                p.method_7336(class_1934.field_9215);
            }
        }

        reset(server);

        server.method_3760().method_43514(
                class_2561.method_43470("Round Ended!").method_27692(class_124.field_1065),
                false
        );
    }

    // =========================
    // SOFT RESET (clears roles but keeps players in game)
    // =========================

    public static void softReset(MinecraftServer server) {

        for (UUID id : new HashSet<>(FROZEN)) {
            class_3222 p = server.method_3760().method_14602(id);
            if (p != null) {
                TagIceInteractHandler.removeIceCage(p);
            }
        }

        FREEZERS.clear();
        FROZEN.clear();
        FROZEN_SINCE.clear();
        TagIceInteractHandler.FREEZE_TIMERS.clear();
        RUNNER_START.clear();
        PLAYER_NAMES.clear();

        killer = null;
        chaser = null;
        gameRunning = false;

        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_5834(false);
            if (p.method_7325()) {
                p.method_7336(class_1934.field_9215);
            }
        }

        if (server != null) {
            class_269 scoreboard = server.method_3845();
            for (String teamName : new String[]{TEAM_CHASER, TEAM_FREEZER, TEAM_KILLER, TEAM_RUNNER}) {
                class_268 t = scoreboard.method_1153(teamName);
                if (t != null) {
                    new HashSet<>(t.method_1204()).forEach(scoreboard::method_1195);
                }
            }
        }
    }

    // =========================
    // RESET
    // =========================

    public static void reset(MinecraftServer server) {

        gameRunning = false;
        restarting = false;

        FREEZERS.clear();
        FROZEN.clear();
        FROZEN_SINCE.clear();
        TagIceInteractHandler.FREEZE_TIMERS.clear();

        RUNNER_START.clear();
        PLAYER_NAMES.clear();

        killer = null;
        chaser = null;

        longestSurvivor = null;
        longestSurvivalTime = 0;

        roundEnding = false;

        if (server != null) {
            class_269 scoreboard = server.method_3845();
            for (String teamName : new String[]{TEAM_CHASER, TEAM_FREEZER, TEAM_KILLER, TEAM_RUNNER}) {
                class_268 t = scoreboard.method_1153(teamName);
                if (t != null) {
                    new HashSet<>(t.method_1204()).forEach(scoreboard::method_1195);
                }
            }
            for (class_3222 p : server.method_3760().method_14571()) {
                p.method_5834(false);
            }
        }
    }

    // =========================
    // ICE CAGE
    // =========================

    public static void buildIceCage(class_3222 p) {

        class_2338 base = p.method_24515();
        var w = p.method_51469();

        w.method_8501(base.method_10074(), class_2246.field_10499.method_9564());

        class_2338[] positions = {
                base.method_10095(),
                base.method_10072(),
                base.method_10078(),
                base.method_10067(),
                base.method_10095().method_10084(),
                base.method_10072().method_10084(),
                base.method_10078().method_10084(),
                base.method_10067().method_10084(),
                base.method_10084().method_10084()
        };

        for (class_2338 b : positions) {
            w.method_8501(b, class_2246.field_10295.method_9564());
        }
    }

    // =========================
    // TITLE HELPER
    // =========================

    public static void sendTitle(class_3222 player, class_2561 title, class_2561 subtitle) {
        player.field_13987.method_14364(new class_5905(5, 15, 5));
        player.field_13987.method_14364(new class_5904(title));
        player.field_13987.method_14364(new class_5903(subtitle));
    }
}