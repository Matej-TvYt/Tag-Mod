package com.example.tagmod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class TagCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {

        // /tagstart
        dispatcher.register(
                class_2170.method_9247("tagstart")
                        .requires(s -> s.method_9259(2))
                        .executes(ctx -> {

                            if (TagGame.gameRunning) {
                                ctx.getSource().method_9226(
                                        () -> class_2561.method_43470("A round is already running.").method_27692(class_124.field_1061),
                                        false
                                );
                                return 0;
                            }

                            String name = ctx.getSource().method_9214();
                            TagGame.start(ctx.getSource().method_9211());

                            ctx.getSource().method_9211().method_3760().method_43514(
                                    class_2561.method_43470(name + " started the round.").method_27692(class_124.field_1060),
                                    false
                            );

                            return 1;
                        })
        );

        // /tagstop
        dispatcher.register(
                class_2170.method_9247("tagstop")
                        .requires(s -> s.method_9259(2))
                        .executes(ctx -> {

                            if (!TagGame.gameRunning) {
                                ctx.getSource().method_9226(
                                        () -> class_2561.method_43470("No round is currently running.").method_27692(class_124.field_1061),
                                        false
                                );
                                return 0;
                            }

                            String name = ctx.getSource().method_9214();
                            TagGame.stop(ctx.getSource().method_9211());

                            ctx.getSource().method_9211().method_3760().method_43514(
                                    class_2561.method_43470(name + " ended the round.").method_27692(class_124.field_1065),
                                    false
                            );

                            return 1;
                        })
        );

        // /tag config ...
        dispatcher.register(
                class_2170.method_9247("tag")
                        .requires(s -> s.method_9259(2))

                        .then(class_2170.method_9247("config")

                                // /tag config normalMode
                                .then(class_2170.method_9247("normalMode")
                                        .executes(ctx -> {

                                            String name = ctx.getSource().method_9214();

                                            if (TagGame.freezeMode) {
                                                TagGame.freezeMode = false;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " disabled Freeze Mode.").method_27692(class_124.field_1054),
                                                        false
                                                );
                                            }

                                            if (TagGame.killerMode) {
                                                TagGame.killerMode = false;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " disabled Killer Mode.").method_27692(class_124.field_1054),
                                                        false
                                                );
                                            }

                                            ctx.getSource().method_9211().method_3760().method_43514(
                                                    class_2561.method_43470(name + " enabled Normal Mode.").method_27692(class_124.field_1060),
                                                    false
                                            );

                                            return 1;
                                        })
                                )

                                // /tag config freezeMode
                                .then(class_2170.method_9247("freezeMode")
                                        .executes(ctx -> {

                                            String name = ctx.getSource().method_9214();

                                            if (TagGame.freezeMode) {
                                                TagGame.freezeMode = false;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " disabled Freeze Mode.").method_27692(class_124.field_1054),
                                                        false
                                                );
                                            } else {
                                                if (TagGame.killerMode) {
                                                    TagGame.killerMode = false;
                                                    ctx.getSource().method_9211().method_3760().method_43514(
                                                            class_2561.method_43470(name + " disabled Killer Mode.").method_27692(class_124.field_1054),
                                                            false
                                                    );
                                                }
                                                TagGame.freezeMode = true;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " enabled Freeze Mode.").method_27692(class_124.field_1075),
                                                        false
                                                );
                                            }

                                            return 1;
                                        })
                                )

                                // /tag config killerMode
                                .then(class_2170.method_9247("killerMode")
                                        .executes(ctx -> {

                                            String name = ctx.getSource().method_9214();

                                            if (TagGame.killerMode) {
                                                TagGame.killerMode = false;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " disabled Killer Mode.").method_27692(class_124.field_1054),
                                                        false
                                                );
                                            } else {
                                                if (TagGame.freezeMode) {
                                                    TagGame.freezeMode = false;
                                                    ctx.getSource().method_9211().method_3760().method_43514(
                                                            class_2561.method_43470(name + " disabled Freeze Mode.").method_27692(class_124.field_1054),
                                                            false
                                                    );
                                                }
                                                TagGame.killerMode = true;
                                                ctx.getSource().method_9211().method_3760().method_43514(
                                                        class_2561.method_43470(name + " enabled Killer Mode.").method_27692(class_124.field_1061),
                                                        false
                                                );
                                            }

                                            return 1;
                                        })
                                )
                        )
        );
    }
}