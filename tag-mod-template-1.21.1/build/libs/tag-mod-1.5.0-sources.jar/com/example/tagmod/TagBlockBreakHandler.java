package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_2246;
import net.minecraft.class_3222;

public class TagBlockBreakHandler {

    public static void register() {

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {

            if (world.method_8608()) return true;

            if (!(player instanceof class_3222 sp)) return true;

            // protect ice and barrier during freeze mode
            if (state.method_27852(class_2246.field_10295) || state.method_27852(class_2246.field_10499)) {

                if (!TagGame.gameRunning || !TagGame.freezeMode) return false;

                // only runners who are not frozen can break it
                if (TagGame.isRunner(sp.method_5667()) && !TagGame.isFrozen(sp.method_5667())) {
                    // allow — world.breakBlock handles instant break via TagIceInteractHandler
                    return false; // still block normal break, interact handler does it
                }

                return false;
            }

            return true;
        });
    }
}