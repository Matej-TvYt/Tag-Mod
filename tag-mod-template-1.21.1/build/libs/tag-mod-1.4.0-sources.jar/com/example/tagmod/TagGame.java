package com.example.tagmod;

import net.minecraft.class_124;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class TagGame {

    // =========================
    // GAME STATE
    // =========================

    public static boolean roundEnding = false;
    public static long roundEndingStart = 0;
    public static boolean gameRunning = false;
    public static boolean freezeMode = false;

    // normal mode
    public static UUID chaser = null;

    // freeze mode
    public static final Set<UUID> FREEZERS = new HashSet<>();
    public static final Set<UUID> FROZEN = new HashSet<>();
    public static final Map<UUID, Long> FROZEN_SINCE = new HashMap<>();

    // runner tracking
    public static final Map<UUID, Long> RUNNER_START = new HashMap<>();
    public static final Map<UUID, String> PLAYER_NAMES = new HashMap<>();

    public static UUID longestSurvivor = null;
    public static long longestSurvivalTime = 0;

    public static boolean endingRound = false;

    // HUD/actionbar
    private static final Map<UUID, Integer> ACTIONBAR_TICKS = new HashMap<>();
    private static final Map<UUID, class_2561> ACTIONBAR_TEXT = new HashMap<>();

    private static final Random RANDOM = new Random();

    // =========================
    // STATE CHECKS
    // =========================

    public static boolean isRunning() {
        return gameRunning;
    }

    public static boolean isChaser(UUID id) {
        return chaser != null && chaser.equals(id);
    }

    public static boolean isFreezer(UUID id) {
        return FREEZERS.contains(id);
    }

    public static boolean isFrozen(UUID id) {
        return FROZEN.contains(id);
    }

    public static boolean isRunner(UUID id) {
        return !FREEZERS.contains(id);
    }

    // =========================
    // START
    // =========================

    public static void start(MinecraftServer server) {

        List<class_3222> players =
                server.method_3760().method_14571();

        if (players.size() < 2) {

            server.method_3760().method_43514(
                    class_2561.method_43470("Need at least 2 players to start.")
                            .method_27692(class_124.field_1061),
                    false
            );

            return;
        }

        if (freezeMode && players.size() < 3) {

            server.method_3760().method_43514(
                    class_2561.method_43470("Need at least 3 players for Freeze Mode.")
                            .method_27692(class_124.field_1061),
                    false
            );

            return;
        }

        resetRound(server);

        gameRunning = true;

        RUNNER_START.clear();
        PLAYER_NAMES.clear();

        longestSurvivor = null;
        longestSurvivalTime = 0;

        for (class_3222 p : players) {

            PLAYER_NAMES.put(
                    p.method_5667(),
                    p.method_5477().getString()
            );
        }

        class_3222 selected =
                players.get(RANDOM.nextInt(players.size()));

        // =========================
        // FREEZE MODE
        // =========================

        if (freezeMode) {

            FREEZERS.add(selected.method_5667());

            for (class_3222 p : players) {

                if (!p.method_5667().equals(selected.method_5667())) {

                    RUNNER_START.put(
                            p.method_5667(),
                            System.currentTimeMillis()
                    );
                }
            }

            server.method_3760().method_43514(
                    class_2561.method_43470(
                            "Tag game started, "
                                    + selected.method_5477().getString()
                                    + " Is the FREEZER!"
                    ).method_27692(class_124.field_1075),
                    false
            );

            for (class_3222 p : players) {

                if (isFreezer(p.method_5667())) {

                    showActionbar(
                            p,
                            class_2561.method_43470("You became a Freezer")
                                    .method_27692(class_124.field_1075)
                    );

                } else {

                    showActionbar(
                            p,
                            class_2561.method_43470("You became a Runner")
                                    .method_27692(class_124.field_1060)
                    );
                }
            }

        } else {

            // =========================
            // NORMAL MODE
            // =========================

            chaser = selected.method_5667();

            for (class_3222 p : players) {

                if (!p.method_5667().equals(selected.method_5667())) {

                    RUNNER_START.put(
                            p.method_5667(),
                            System.currentTimeMillis()
                    );
                }
            }

            server.method_3760().method_43514(
                    class_2561.method_43470(
                            "Tag game started, "
                                    + selected.method_5477().getString()
                                    + " Is the CHASER!"
                    ).method_27692(class_124.field_1061),
                    false
            );

            for (class_3222 p : players) {

                if (isChaser(p.method_5667())) {

                    showActionbar(
                            p,
                            class_2561.method_43470("You became the Chaser")
                                    .method_27692(class_124.field_1061)
                    );

                } else {

                    showActionbar(
                            p,
                            class_2561.method_43470("You became a Runner")
                                    .method_27692(class_124.field_1060)
                    );
                }
            }
        }

        syncAll(server);
    }

    // =========================
    // STOP
    // =========================

    public static void stop(MinecraftServer server) {

        gameRunning = false;

        for (class_3222 p :
                server.method_3760().method_14571()) {

            roundEnding = false;
            roundEndingStart = 0;
            p.method_5834(false);
            p.method_5875(false);

            if (FROZEN.contains(p.method_5667())) {
                removeIceCage(p);
            }
        }

        chaser = null;

        FREEZERS.clear();
        FROZEN.clear();
        FROZEN_SINCE.clear();

        RUNNER_START.clear();
        PLAYER_NAMES.clear();

        longestSurvivor = null;
        longestSurvivalTime = 0;

        endingRound = false;

        ACTIONBAR_TICKS.clear();
        ACTIONBAR_TEXT.clear();

        clearTeams(server);

        server.method_3760().method_43514(
                class_2561.method_43470("Tag game stopped.")
                        .method_27692(class_124.field_1061),
                false
        );
    }

    // =========================
    // RESET ROUND
    // =========================

    private static void resetRound(MinecraftServer server) {

        for (class_3222 p :
                server.method_3760().method_14571()) {

            roundEnding = false;
            roundEndingStart = 0;
            p.method_5834(false);
            p.method_5875(false);

            if (FROZEN.contains(p.method_5667())) {
                removeIceCage(p);
            }
        }

        chaser = null;

        FREEZERS.clear();
        FROZEN.clear();
        FROZEN_SINCE.clear();

        RUNNER_START.clear();
        PLAYER_NAMES.clear();

        longestSurvivor = null;
        longestSurvivalTime = 0;

        endingRound = false;

        ACTIONBAR_TICKS.clear();
        ACTIONBAR_TEXT.clear();

        clearTeams(server);
    }

    // =========================
    // NORMAL TAG TRANSFER
    // =========================

    public static void transferChase(
            MinecraftServer server,
            UUID newChaser
    ) {

        if (!gameRunning) return;
        if (freezeMode) return;

        chaser = newChaser;

        for (class_3222 p :
                server.method_3760().method_14571()) {

            if (isChaser(p.method_5667())) {

                showActionbar(
                        p,
                        class_2561.method_43470("You became the Chaser")
                                .method_27692(class_124.field_1061)
                );

            } else {

                showActionbar(
                        p,
                        class_2561.method_43470("You became a Runner")
                                .method_27692(class_124.field_1060)
                );
            }
        }

        syncAll(server);
    }

    // =========================
    // FREEZE PLAYER
    // =========================

    public static void freeze(class_3222 target) {

        if (!gameRunning || !freezeMode)
            return;

        UUID id = target.method_5667();

        if (FREEZERS.contains(id))
            return;

        if (FROZEN.contains(id))
            return;

        // save survival result ONCE
        if (RUNNER_START.containsKey(id)) {

            long survived =
                    System.currentTimeMillis()
                            - RUNNER_START.get(id);

            if (survived > longestSurvivalTime) {

                longestSurvivalTime = survived;
                longestSurvivor = id;
            }
        }

        FROZEN.add(id);

        FROZEN_SINCE.put(
                id,
                System.currentTimeMillis()
        );

        buildIceCage(target);

        showActionbar(
                target,
                class_2561.method_43470(
                        "You got Freezed, wait to get Unfreezed."
                ).method_27692(class_124.field_1075)
        );
    }

    // =========================
    // UNFREEZE PLAYER
    // =========================

    public static void unfreeze(class_3222 target) {

        UUID id = target.method_5667();

        if (!FROZEN.contains(id))
            return;

        FROZEN.remove(id);
        FROZEN_SINCE.remove(id);

        removeIceCage(target);

        target.method_5875(false);

        showActionbar(
                target,
                class_2561.method_43470("You got Unfreezed.")
                        .method_27692(class_124.field_1078)
        );
    }

    // =========================
    // TICK
    // =========================

    public static void tick(MinecraftServer server) {

        if (!gameRunning)
            return;

        // actionbar
        for (class_3222 p :
                server.method_3760().method_14571()) {

            UUID id = p.method_5667();

            Integer ticks =
                    ACTIONBAR_TICKS.get(id);

            if (ticks == null)
                continue;

            if (ticks > 0) {

                p.method_7353(
                        ACTIONBAR_TEXT.get(id),
                        true
                );

                ACTIONBAR_TICKS.put(id, ticks - 1);

            } else {

                ACTIONBAR_TICKS.remove(id);
                ACTIONBAR_TEXT.remove(id);
            }
        }

        if (!freezeMode)
            return;

        List<UUID> convert = new ArrayList<>();

        for (class_3222 p :
                server.method_3760().method_14571()) {

            UUID id = p.method_5667();

            if (!FROZEN.contains(id)) {

                p.method_5875(false);

                continue;
            }

            // hard freeze
            p.method_18800(0, 0, 0);
            p.field_6037 = true;

            p.method_5875(true);

            p.method_14251(
                    p.method_51469(),
                    p.method_23317(),
                    p.method_23318(),
                    p.method_23321(),
                    p.method_36454(),
                    p.method_36455()
            );

            long elapsed =
                    (System.currentTimeMillis()
                            - FROZEN_SINCE.get(id)) / 1000;

            long remain =
                    Math.max(0, 60 - elapsed);

            p.method_7353(
                    class_2561.method_43470(
                            remain
                                    + "s Until you become a Freezer."
                    ).method_27692(class_124.field_1075),
                    true
            );

            if (elapsed >= 60) {
                convert.add(id);
            }
        }

        // convert frozen -> freezer
        for (UUID id : convert) {

            class_3222 p =
                    server.method_3760().method_14602(id);

            if (p == null)
                continue;

            removeIceCage(p);

            FROZEN.remove(id);
            FROZEN_SINCE.remove(id);

            FREEZERS.add(id);

            p.method_5875(false);

            showActionbar(
                    p,
                    class_2561.method_43470("You became a Freezer")
                            .method_27692(class_124.field_1075)
            );
        }

        syncAll(server);

        checkForFreezeWin(server);
    }

    // =========================
    // ROUND END
    // =========================

    public static void checkForFreezeWin(
            MinecraftServer server
    ) {

        if (!freezeMode || !gameRunning)
            return;

        int aliveRunners = 0;

        // count NON-FROZEN runners
        for (class_3222 p :
                server.method_3760().method_14571()) {

            UUID id = p.method_5667();

            if (isRunner(id)
                    && !isFrozen(id)) {

                aliveRunners++;
            }
        }

        // at least one runner still alive
        if (aliveRunners > 0) {

            roundEnding = false;

            return;
        }

        // START END COUNTDOWN
        if (!roundEnding) {

            roundEnding = true;

            roundEndingStart =
                    System.currentTimeMillis();
        }

        long elapsed =
                (System.currentTimeMillis()
                        - roundEndingStart) / 1000;

        long remain =
                Math.max(0, 10 - elapsed);

        // HUD FOR ALL PLAYERS
        for (class_3222 p :
                server.method_3760().method_14571()) {

            p.method_7353(
                    class_2561.method_43470(
                            remain +
                                    " Until round ends."
                    ).method_27692(class_124.field_1065),
                    true
            );
        }

        // still counting
        if (elapsed < 10)
            return;

        roundEnding = false;

        String winnerName = "Unknown";

        if (longestSurvivor != null
                && PLAYER_NAMES.containsKey(longestSurvivor)) {

            winnerName =
                    PLAYER_NAMES.get(longestSurvivor);
        }

        long totalSeconds =
                longestSurvivalTime / 1000;

        long minutes =
                totalSeconds / 60;

        long seconds =
                totalSeconds % 60;

        // REMOVE ALL ICE
        for (class_3222 p :
                server.method_3760().method_14571()) {

            if (isFrozen(p.method_5667())) {

                removeIceCage(p);

                p.method_5875(false);
            }
        }

        FROZEN.clear();
        FROZEN_SINCE.clear();

        // SHOW STATS
        server.method_3760().method_43514(
                class_2561.method_43470(
                        winnerName
                                + " survived the longest: "
                                + minutes + "m "
                                + seconds + "s"
                ).method_27692(class_124.field_1065),
                false
        );

        stop(server);
    }

    // =========================
    // HUD
    // =========================

    private static void showActionbar(
            class_3222 player,
            class_2561 text
    ) {

        ACTIONBAR_TEXT.put(
                player.method_5667(),
                text
        );

        ACTIONBAR_TICKS.put(
                player.method_5667(),
                40
        );

        player.method_7353(text, true);
    }

    // =========================
    // GLOWING TEAMS
    // =========================

    public static void syncAll(MinecraftServer server) {

        try {

            class_269 scoreboard =
                    server.method_3845();

            class_268 freezerTeam =
                    scoreboard.method_1153("tag_freezer");

            if (freezerTeam == null) {

                freezerTeam =
                        scoreboard.method_1171("tag_freezer");

                freezerTeam.method_1141(class_124.field_1075);
            }

            class_268 chaserTeam =
                    scoreboard.method_1153("tag_chaser");

            if (chaserTeam == null) {

                chaserTeam =
                        scoreboard.method_1171("tag_chaser");

                chaserTeam.method_1141(class_124.field_1061);
            }

            for (class_3222 p :
                    server.method_3760().method_14571()) {

                String entry =
                        p.method_5820();

                if (freezerTeam.method_1204().contains(entry)) {
                    scoreboard.method_1157(
                            entry,
                            freezerTeam
                    );
                }

                if (chaserTeam.method_1204().contains(entry)) {
                    scoreboard.method_1157(
                            entry,
                            chaserTeam
                    );
                }

                p.method_5834(false);

                if (!gameRunning)
                    continue;

                if (freezeMode) {

                    if (isFreezer(p.method_5667())) {

                        scoreboard.method_1172(
                                entry,
                                freezerTeam
                        );

                        p.method_5834(true);
                    }

                } else {

                    if (isChaser(p.method_5667())) {

                        scoreboard.method_1172(
                                entry,
                                chaserTeam
                        );

                        p.method_5834(true);
                    }
                }
            }

        } catch (Throwable t) {

            t.printStackTrace();
        }
    }

    private static void clearTeams(
            MinecraftServer server
    ) {

        try {

            class_269 scoreboard =
                    server.method_3845();

            class_268 freezerTeam =
                    scoreboard.method_1153("tag_freezer");

            if (freezerTeam != null) {

                for (String entry :
                        new HashSet<>(freezerTeam.method_1204())) {

                    scoreboard.method_1157(
                            entry,
                            freezerTeam
                    );
                }
            }

            class_268 chaserTeam =
                    scoreboard.method_1153("tag_chaser");

            if (chaserTeam != null) {

                for (String entry :
                        new HashSet<>(chaserTeam.method_1204())) {

                    scoreboard.method_1157(
                            entry,
                            chaserTeam
                    );
                }
            }

        } catch (Throwable t) {

            t.printStackTrace();
        }
    }

    // =========================
    // ICE CAGE
    // =========================

    private static void buildIceCage(
            class_3222 p
    ) {

        class_2338 base = p.method_24515();

        var w = p.method_51469();

        class_2338[] cage = new class_2338[] {

                base.method_10074(),

                base.method_10095(),
                base.method_10072(),
                base.method_10078(),
                base.method_10067(),

                base.method_10095().method_10084(),
                base.method_10072().method_10084(),
                base.method_10078().method_10084(),
                base.method_10067().method_10084(),

                base.method_10084().method_10084()
        };

        for (class_2338 pos : cage) {

            if (w.method_22347(pos)) {

                w.method_8501(
                        pos,
                        class_2246.field_10295.method_9564()
                );
            }
        }
    }

    private static void removeIceCage(
            class_3222 p
    ) {

        class_2338 base = p.method_24515();

        var w = p.method_51469();

        class_2338[] cage = new class_2338[] {

                base.method_10074(),

                base.method_10095(),
                base.method_10072(),
                base.method_10078(),
                base.method_10067(),

                base.method_10095().method_10084(),
                base.method_10072().method_10084(),
                base.method_10078().method_10084(),
                base.method_10067().method_10084(),

                base.method_10084().method_10084()
        };

        for (class_2338 pos : cage) {

            if (w.method_8320(pos).method_27852(class_2246.field_10295)) {

                w.method_22352(pos, false);
            }
        }
    }
}