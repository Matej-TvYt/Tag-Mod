package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_3222;

public class TagHitHandler {

    public static void register() {

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;

            if (!(player instanceof class_3222 attacker)) return class_1269.field_5811;
            if (!(entity instanceof class_3222 target)) return class_1269.field_5811;

            if (!TagGame.gameRunning) return class_1269.field_5811;

            // ---- FREEZE MODE ----
            if (TagGame.freezeMode) {

                // only freezers can freeze
                if (!TagGame.isFreezer(attacker.method_5667())) return class_1269.field_5811;

                // can't freeze self, can't freeze freezers, can't freeze already frozen
                if (attacker.method_5667().equals(target.method_5667())) return class_1269.field_5814;
                if (TagGame.isFreezer(target.method_5667())) return class_1269.field_5814;
                if (TagGame.isFrozen(target.method_5667())) return class_1269.field_5814;

                TagGame.freeze(target);
                return class_1269.field_5812;
            }

            // ---- NORMAL MODE ----
            if (!TagGame.isChaser(attacker.method_5667())) return class_1269.field_5811;
            if (TagGame.isChaser(target.method_5667())) return class_1269.field_5814;

            TagGame.transferChase(attacker.method_5682(), target.method_5667());
            return class_1269.field_5812;
        });
    }
}