package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class TagIceInteractHandler {

    public static void register() {

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {

            if (world.method_8608()) return class_1269.field_5811;

            if (!(player instanceof class_3222 sp))
                return class_1269.field_5811;

            if (!TagGame.gameRunning || !TagGame.freezeMode)
                return class_1269.field_5811;

            if (world.method_8320(pos).method_27852(class_2246.field_10295)) {

                // BLOCK ALL NORMAL BREAKING
                tryRunnerUnfreeze(sp, pos);

                return class_1269.field_5814;
            }

            return class_1269.field_5811;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {

            if (world.method_8608()) return class_1269.field_5811;

            if (!(player instanceof class_3222 sp))
                return class_1269.field_5811;

            if (!TagGame.gameRunning || !TagGame.freezeMode)
                return class_1269.field_5811;

            if (!(hit instanceof class_3965 bhr))
                return class_1269.field_5811;

            class_2338 pos = bhr.method_17777();

            if (world.method_8320(pos).method_27852(class_2246.field_10295)) {

                tryRunnerUnfreeze(sp, pos);

                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });
    }

    private static void tryRunnerUnfreeze(class_3222 clicker, class_2338 icePos) {

        // ONLY RUNNERS CAN UNFREEZE
        if (!TagGame.isRunner(clicker.method_5667()))
            return;

        // FROZEN PLAYERS CANNOT UNFREEZE
        if (TagGame.isFrozen(clicker.method_5667()))
            return;

        for (class_3222 target :
                clicker.method_5682().method_3760().method_14571()) {

            if (!TagGame.isFrozen(target.method_5667()))
                continue;

            class_2338 base = target.method_24515();

            class_2338[] cage = new class_2338[] {
                    base.method_10074(),
                    base.method_10095(),
                    base.method_10072(),
                    base.method_10078(),
                    base.method_10067(),
                    base.method_10095().method_10084(),
                    base.method_10072().method_10084(),
                    base.method_10078().method_10084(),
                    base.method_10067().method_10084(),
                    base.method_10084().method_10084()
            };

            for (class_2338 p : cage) {

                if (p.equals(icePos)) {

                    TagGame.unfreeze(target);

                    return;
                }
            }
        }
    }
}