package com.example.tagmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class TagCommand {

    public static void register(com.mojang.brigadier.CommandDispatcher<class_2168> dispatcher) {

        // /tagstart
        dispatcher.register(
                class_2170.method_9247("tagstart")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> {
                            TagGame.start(ctx.getSource().method_9211());
                            return 1;
                        })
        );

        // /tagstop
        dispatcher.register(
                class_2170.method_9247("tagstop")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> {
                            TagGame.stop(ctx.getSource().method_9211());
                            return 1;
                        })
        );

        // /tag config ...
        dispatcher.register(
                class_2170.method_9247("tag")
                        .requires(source -> source.method_9259(2))

                        // freezeMode enable
                        .then(class_2170.method_9247("config")
                                .then(class_2170.method_9247("freezeMode")

                                        .then(class_2170.method_9247("enable")
                                                .executes(ctx -> {

                                                    if (ctx.getSource().method_9211()
                                                            .method_3760()
                                                            .method_14571()
                                                            .size() < 3) {

                                                        ctx.getSource().method_9213(
                                                                class_2561.method_43470("Need at least 3 players for Freeze Mode.")
                                                                        .method_27692(class_124.field_1061)
                                                        );
                                                        return 0;
                                                    }

                                                    TagGame.freezeMode = true;

                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470("Freeze Mode enabled.")
                                                                    .method_27692(class_124.field_1075),
                                                            false
                                                    );

                                                    return 1;
                                                }))

                                        .then(class_2170.method_9247("disable")
                                                .executes(ctx -> {

                                                    TagGame.freezeMode = false;

                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470("Freeze Mode disabled.")
                                                                    .method_27692(class_124.field_1061),
                                                            false
                                                    );

                                                    return 1;
                                                }))
                                )

                                // worldBorder
                                .then(class_2170.method_9247("worldBorder")

                                        .then(class_2170.method_9247("normal")
                                                .executes(ctx -> {

                                                    ctx.getSource().method_9211()
                                                            .method_30002()
                                                            .method_8621()
                                                            .method_11969(60000000);

                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470("World border reset.")
                                                                    .method_27692(class_124.field_1060),
                                                            false
                                                    );

                                                    return 1;
                                                }))

                                        .then(class_2170.method_9244(
                                                        "size",
                                                        IntegerArgumentType.integer(1, 30000000)
                                                )
                                                .executes(ctx -> {

                                                    int size = IntegerArgumentType.getInteger(ctx, "size");

                                                    ctx.getSource().method_9211()
                                                            .method_30002()
                                                            .method_8621()
                                                            .method_11969(size * 2.0);

                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470("World border set to " + size)
                                                                    .method_27692(class_124.field_1060),
                                                            false
                                                    );

                                                    return 1;
                                                }))
                                )
                        )
        );
    }
}