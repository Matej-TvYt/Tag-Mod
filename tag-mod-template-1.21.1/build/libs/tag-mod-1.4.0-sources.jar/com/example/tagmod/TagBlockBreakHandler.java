package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_2246;

public class TagBlockBreakHandler {

    public static void register() {

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {

            // Always protect ICE blocks from real breaking
            if (state.method_27852(class_2246.field_10295)) {
                return false;
            }

            return true;
        });
    }
}