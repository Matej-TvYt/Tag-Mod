package com.example.tagmod;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;

import static net.minecraft.class_2170.method_9247;

public class TagCommand {

    public static void register() {

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("tagstart")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        TagGame.start(source.method_9211());
                        return 1;
                    })
            );
        });
    }
}