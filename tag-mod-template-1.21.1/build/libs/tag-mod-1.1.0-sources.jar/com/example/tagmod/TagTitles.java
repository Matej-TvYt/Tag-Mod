package com.example.tagmod;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class TagTitles {

    public static void showRunner(class_3222 player) {
        player.method_7353(
                class_2561.method_43470("You became a RUNNER")
                        .method_27692(class_124.field_1060),
                true
        );
    }

    public static void showChaser(class_3222 player) {
        player.method_7353(
                class_2561.method_43470("You became a CHASER")
                        .method_27692(class_124.field_1061),
                true
        );
    }
}