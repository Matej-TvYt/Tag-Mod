package com.example.tagmod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class TagBorderEnforcer {

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(TagBorderEnforcer::tick);
    }

    private static void tick(MinecraftServer server) {
        if (!TagGame.gameRunning) return;

        double half = TagGame.BORDER_SIZE / 2.0;

        double minX = TagGame.BORDER_CENTER_X - half;
        double maxX = TagGame.BORDER_CENTER_X + half;
        double minZ = TagGame.BORDER_CENTER_Z - half;
        double maxZ = TagGame.BORDER_CENTER_Z + half;

        for (class_3222 player : server.method_3760().method_14571()) {

            double x = player.method_23317();
            double y = player.method_23318();
            double z = player.method_23321();

            boolean outside =
                    x < minX || x > maxX ||
                            z < minZ || z > maxZ;

            if (!outside) continue;

            double clampedX = Math.max(minX, Math.min(maxX, x));
            double clampedZ = Math.max(minZ, Math.min(maxZ, z));

            player.method_5859(clampedX, y, clampedZ);
        }
    }
}