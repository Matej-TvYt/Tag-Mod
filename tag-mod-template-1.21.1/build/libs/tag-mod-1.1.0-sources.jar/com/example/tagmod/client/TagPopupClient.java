package com.example.tagmod.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class TagPopupClient {

    private static long showUntil = 0;
    private static class_2561 currentText = null;

    public static void show(class_2561 text, long durationMs) {
        currentText = text;
        showUntil = System.currentTimeMillis() + durationMs;
    }

    public static void render(class_332 context) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || currentText == null) return;

        if (System.currentTimeMillis() > showUntil) {
            currentText = null;
            return;
        }

        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();

        int textWidth = client.field_1772.method_27525(currentText);

        context.method_27535(
                client.field_1772,
                currentText,
                width / 2 - textWidth / 2,
                height / 2,
                0xFFFFFF
        );
    }
}