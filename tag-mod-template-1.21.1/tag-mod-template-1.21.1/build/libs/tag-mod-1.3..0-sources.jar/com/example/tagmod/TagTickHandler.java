package com.example.tagmod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;

public class TagTickHandler {

    public static void register() {

        ServerTickEvents.END_SERVER_TICK.register(server -> {

            if (!TagGame.isRunning()) return;

            for (class_3222 player : server.method_3760().method_14571()) {
                player.method_5834(TagGame.isChaser(player.method_5667()));
            }
        });
    }
}