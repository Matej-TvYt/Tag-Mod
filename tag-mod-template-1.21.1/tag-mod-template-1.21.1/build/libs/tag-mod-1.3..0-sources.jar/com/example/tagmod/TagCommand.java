package com.example.tagmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_2784;
import net.minecraft.class_3218;

import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2170.method_9244;

public class TagCommand {

    public static void register(com.mojang.brigadier.CommandDispatcher<class_2168> dispatcher) {

        dispatcher.register(
                method_9247("tagstart")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> {

                            TagGame.start(ctx.getSource().method_9211());

                            return 1;
                        })
        );

        dispatcher.register(
                method_9247("tagstop")
                        .requires(source -> source.method_9259(2))
                        .executes(ctx -> {

                            TagGame.stop(ctx.getSource().method_9211());

                            ctx.getSource().method_9226(
                                    () -> class_2561.method_43470("Tag game stopped.")
                                            .method_27692(class_124.field_1061),
                                    true
                            );

                            return 1;
                        })
        );

        dispatcher.register(
                method_9247("tag")
                        .requires(source -> source.method_9259(2))

                        // =========================
                        // /tag modify worldBorder <size>
                        // =========================
                        .then(
                                method_9247("modify")
                                        .then(
                                                method_9247("worldBorder")

                                                        .then(
                                                                method_9244(
                                                                        "size",
                                                                        IntegerArgumentType.integer(1, 30000000)
                                                                )

                                                                        .executes(ctx -> {

                                                                            int size = IntegerArgumentType.getInteger(ctx, "size");

                                                                            class_3218 world =
                                                                                    ctx.getSource()
                                                                                            .method_9211()
                                                                                            .method_30002();

                                                                            class_2784 border = world.method_8621();

                                                                            border.method_11978(0, 0);
                                                                            border.method_11969(size * 2.0);

                                                                            ctx.getSource().method_9226(
                                                                                    () -> class_2561.method_43470(
                                                                                                    "World border set to "
                                                                                                            + size
                                                                                                            + " blocks."
                                                                                            )
                                                                                            .method_27692(class_124.field_1060),
                                                                                    true
                                                                            );

                                                                            return 1;
                                                                        })
                                                        )

                                                        // =========================
                                                        // /tag modify worldBorder normal
                                                        // =========================
                                                        .then(
                                                                method_9247("normal")
                                                                        .executes(ctx -> {

                                                                            class_3218 world =
                                                                                    ctx.getSource()
                                                                                            .method_9211()
                                                                                            .method_30002();

                                                                            class_2784 border = world.method_8621();

                                                                            border.method_11978(0, 0);

                                                                            // Vanilla default
                                                                            border.method_11969(60000000);

                                                                            ctx.getSource().method_9226(
                                                                                    () -> class_2561.method_43470(
                                                                                                    "World border reset to normal."
                                                                                            )
                                                                                            .method_27692(class_124.field_1054),
                                                                                    true
                                                                            );

                                                                            return 1;
                                                                        })
                                                        )
                                        )
                        )
        );
    }
}