package com.example.tagmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_3222;

public class TagHitHandler {

    public static void register() {

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {

            if (!(player instanceof class_3222 attacker)) return class_1269.field_5811;
            if (!(entity instanceof class_3222 target)) return class_1269.field_5811;

            if (!TagGame.isRunning()) return class_1269.field_5811;

            if (!TagGame.isChaser(attacker.method_5667())) return class_1269.field_5811;

            // ROLE TRANSFER HAPPENS HERE
            TagGame.transferChase(attacker.method_5682(), target.method_5667());

            return class_1269.field_5812;
        });
    }
}