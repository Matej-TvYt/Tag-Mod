package com.example.tagmod;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class TagGame {

    public static boolean gameRunning = false;
    public static UUID chaser = null;

    private static final Random RANDOM = new Random();

    // =====================
    // STATE CHECK
    // =====================
    public static boolean isRunning() {
        return gameRunning;
    }

    public static boolean isChaser(UUID id) {
        return gameRunning && chaser != null && chaser.equals(id);
    }

    // =====================
    // START GAME
    // =====================
    public static void start(MinecraftServer server) {

        List<class_3222> players =
                server.method_3760().method_14571();

        if (players.size() < 2) {

            server.method_3760().method_43514(
                    class_2561.method_43470("Need at least 2 players to start.")
                            .method_27692(class_124.field_1061),
                    false
            );

            return;
        }

        // COUNTDOWN
        for (class_3222 player : players) {

            player.method_17356(
                    class_3417.field_15204.comp_349(),
                    class_3419.field_15250,
                    1.0F,
                    0.9F
            );

            player.method_17356(
                    class_3417.field_15204.comp_349(),
                    class_3419.field_15250,
                    1.0F,
                    1.0F
            );

            player.method_17356(
                    class_3417.field_15204.comp_349(),
                    class_3419.field_15250,
                    1.0F,
                    1.1F
            );
        }

        gameRunning = true;

        class_3222 selected =
                players.get(RANDOM.nextInt(players.size()));

        chaser = selected.method_5667();

        // RAID HORN START SOUND
        for (class_3222 player : players) {

            player.method_17356(
                    class_3417.field_17266.comp_349(),
                    class_3419.field_15250,
                    1.0F,
                    1.0F
            );
        }

        syncState(server);
    }

    // =====================
    // STOP GAME
    // =====================
    public static void stop(MinecraftServer server) {

        gameRunning = false;
        chaser = null;

        class_2960 soundId =
                class_2960.method_60655("tagmod", "game_end");

        for (class_3222 player :
                server.method_3760().method_14571()) {

            player.method_17356(
                    net.minecraft.class_3414.method_47908(soundId),
                    class_3419.field_15250,
                    1.0F,
                    1.0F
            );
        }
    }

    // =====================
    // ROLE TRANSFER
    // =====================
    public static void transferChase(
            MinecraftServer server,
            UUID newChaser
    ) {

        if (!gameRunning) return;
        if (newChaser == null) return;

        chaser = newChaser;

        // COW BELL SOUND
        for (class_3222 player :
                server.method_3760().method_14571()) {

            player.method_17356(
                    class_3417.field_18309.comp_349(),
                    class_3419.field_15250,
                    1.0F,
                    1.0F
            );
        }

        syncState(server);
    }

    // =====================
    // VISUAL/HUD STATE
    // =====================
    public static void syncState(MinecraftServer server) {

        for (class_3222 player :
                server.method_3760().method_14571()) {

            boolean chaserState =
                    isChaser(player.method_5667());

            player.method_5834(chaserState);

            if (chaserState) {

                player.method_7353(
                        class_2561.method_43470("You became the CHASER")
                                .method_27692(class_124.field_1061),
                        true
                );

            } else {

                player.method_7353(
                        class_2561.method_43470("You became a RUNNER")
                                .method_27692(class_124.field_1060),
                        true
                );
            }
        }
    }

    // =====================
    // COMPAT
    // =====================
    public static void applyPlayerState(
            class_3222 player
    ) {

        player.method_5834(
                isChaser(player.method_5667())
        );
    }
}