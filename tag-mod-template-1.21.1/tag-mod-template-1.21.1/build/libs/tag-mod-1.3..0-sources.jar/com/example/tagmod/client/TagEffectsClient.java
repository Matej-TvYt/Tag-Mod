package com.example.tagmod.client;

import com.example.tagmod.TagGame;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1657;

public class TagEffectsClient {

    public static void init() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null) return;

            boolean running = TagGame.isRunning();

            for (class_1657 player : client.field_1687.method_18456()) {

                // BEFORE GAME START → NO GLOW EVER
                if (!running) {
                    player.method_5834(false);
                    continue;
                }

                // AFTER START → ONLY CHASER GLOWS
                if (TagGame.isChaser(player.method_5667())) {
                    player.method_5834(true);
                } else {
                    player.method_5834(false);
                }
            }
        });
    }
}